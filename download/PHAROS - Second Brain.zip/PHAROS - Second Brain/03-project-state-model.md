# Project State Model

## Why This Matters

The project record is the core object of the method brain.

Notes are inputs.
Projects are where continuity becomes work.

## Required Fields

Each live project should maintain the following fields.

### Identity

- project title
- short description
- status: incubating, active, blocked, dormant, archived
- owner or primary agent

### Core Question

- what is this project trying to resolve?
- why does it matter now?

### Current Direction

- current working claim
- current direction of inquiry
- what seems to be emerging

### Canonical State & Artifact

- **Primary Canonical Artifact**: [[Link to the main current synthesis note / deliverable]]
- **Artifact Status**: candidate | working | grounded | canonical | deprecated
- **Supersedes**: [[Previous artifact]]
- **Superseded by**: [[Newer artifact]]
- **Confidence / Prudence Level**:
- **Last Reviewed**:
- **Review Owner / Signatory** (critical for professional/high-responsibility use):

### Active Tensions

- unresolved contradiction
- internal disagreement
- fragile assumption
- ambiguous term
- evidentiary weakness

### Relevant Materials

- core notes
- core sources
- recent conversations
- linked threads
- supporting artifacts

### Recent Moves

- what changed since the last pass?
- what was added, removed, revised, or deprecated?

### Synthesis State

- what has already been integrated?
- what remains only adjacent?
- what needs bridging?
- what is recurring without resolution?

### Contradictions To Preserve

- incompatible interpretations that should remain visible
- unresolved source conflict
- tensions that should not yet be reconciled

### Blockers

- conceptual blocker
- evidentiary blocker
- structural blocker
- energy or stamina blocker

### Consequence Binding (Next Move Impact)

- What real change does the next synthesis move produce?
- What outcome or decision does it advance?
- Who (if anyone) needs to review or sign off?
- What happens if we *don’t* do the next move?

### Next Move

- next synthesis step
- next question
- next draft move
- next retrieval move only if truly necessary

## Minimum Template

```md
# Project: [Title]

## Status

Active | Blocked | Dormant | Archived

## Core Question

[What is this project trying to resolve?]

## Why It Matters Now

[Why this project is live now.]

## Current Direction

[Best present articulation of the project's direction.]

## Canonical State & Artifact
- Primary Canonical Artifact: [[Link]]
- Artifact Status: working | grounded | canonical | deprecated
- Supersedes:
- Superseded by:
- Confidence:
- Last reviewed:
- Review Owner/Signatory:

## Active Tensions

- [Tension 1]
- [Tension 2]
- [Tension 3]

## Contradictions To Preserve

- [Unresolved contradiction]
- [Competing interpretation]

## Relevant Materials

- [Key note or source]
- [Key note or source]

## Recent Moves

- [What changed recently]

## Consequence Binding
- What changes if we execute the next move?
- Real outcome advanced:
- Review/sign-off needed:

## Blockers

- [What is stopping movement]

## Next Synthesis Move

[The next meaningful act of integration.]