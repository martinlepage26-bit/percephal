# Obsidian Implementation Templates

## Why This File Exists

The method brain should be operable inside an ordinary vault.

This file translates the method into practical Obsidian templates and lightweight conventions.
The goal is not to produce a perfect ontology.
The goal is to create the minimum surfaces needed for continuity-preserving project synthesis.

## Core Surfaces

The minimum working set is:

- one daily dashboard
- one active projects hub
- one project-state note per live project
- one agent-log note per session or handoff
- one weekly review note

Everything else is optional until this core is working.

## Folder Pattern (recommended)

```text
Second Brain/
├── 10_Projects/
├── 50_Hubs/
├── 60_Dashboards/
├── 70_Agent Logs/
├── templates/          ← optional
├── governance/
└── (your other folders)
```

## Naming Conventions

- Daily Dashboard - YYYY-MM-DD
- Weekly Review - YYYY-[W]WW
- Project - [Short Title]
- Agent Log - [Project] - YYYY-MM-DD-HHMM

## Template: Daily Dashboard

```md
# Daily Dashboard - {{date:YYYY-MM-DD}}

## Active Projects
- [[Project - ]]
- [[Project - ]]
- [[Project - ]]

## What Is Alive
- [Thread or pressure point]

## What Is Drifting
- [Project or thread at risk of decay]

## What Synthesis Is Overdue
- [What needs integration]

## Highest-Pressure Move
- [One meaningful synthesis move for today]

## Consequence Binding (Today)
- If we do the highest-pressure move today, what actually changes in the project / work / world?

## Continuity Risks
- [Missing state]
- [Stale project record]

## Session Close Check
- [ ] project state updated
- [ ] next synthesis move named
- [ ] contradictions preserved
- [ ] misleading path deprecated or flagged
```

## Template: Active Projects Hub

```md
# Active Projects Hub

## Active
- [[Project - ]]
- [[Project - ]]

## Blocked
- [[Project - ]]

## Dormant
- [[Project - ]]

## Review Queue
- [Project needing canonicality review]
- [Project needing contradiction review]

## Emerging Candidates
- [Thread that may need promotion into a project]
```

## Template: Project State Note

```md
# Project - [Title]

## Status
active | blocked | dormant | archived

## Core Question
[What is this project trying to resolve?]

## Why It Matters Now
[Why this project is live now.]

## Current Direction
[Current working direction or thesis.]

## Canonical State & Artifact
- Primary Canonical Artifact: [[Link to main synthesis note]]
- Artifact Status: working | grounded | canonical | deprecated
- Supersedes:
- Superseded by:
- Confidence:
- Last reviewed:
- Review Owner/Signatory:

## Active Tensions
- [Tension]

## Contradictions To Preserve
- [Unresolved contradiction]
- [Competing interpretation]

## Relevant Materials
- [[Key note or source]]

## Recent Moves
- [What changed recently]

## Consequence Binding
- What changes if we execute the next move?
- Real outcome / decision advanced:
- Review/sign-off needed:

## Blockers
- [Conceptual blocker]
- [Evidence blocker]
- [Energy blocker]

## Next Synthesis Move
[The next meaningful act of integration.]
```

## Template: Agent Log

```md
# Agent Log - [Project] - {{date:YYYY-MM-DD-HHmm}}

## Project Understanding
[What the agent believes the project is trying to do.]

## Changes Made
- [State updated]
- [Material linked]
- [Contradiction surfaced]

## Uncertainties
- [What remains unclear]
- [What may be stale]

## Next Move
[The next step for the human or next agent.]

## References
- [[Project - ]]
- [[Relevant note]]
```

## Template: Weekly Review

```md
# Weekly Review - {{date:YYYY-[W]WW}}

## Active Projects Reviewed
- [[Project - ]]
- [[Project - ]]

## What Moved
- [Real project movement]

## What Drifted
- [Project or thread losing continuity]

## Contradictions Being Preserved
- [Tension not yet to be reconciled]

## Canonicality Checks
- [What became current]
- [What was superseded]
- [What needs review]

## Maintenance Pruning
- [Surface to archive]
- [Hub to simplify]

## Emerging Project Candidates
- [Recurring thread]

## Next Week's Highest-Pressure Project
- [[Project - ]]
```

## Operational Rules (the only rules that matter)

1. Every active project must be resumable from its project note in **under one minute**.
2. Every session must end with a named **next synthesis move**.
3. No new dashboard, hub, or audit unless it clearly reduces work.
4. No synthesis counts as progress until it **changes the project state**.
5. Contradictions must stay visible until actually resolved.

## Bottom Line

These templates exist to make interrupted thought resumable, governable, and project-capable — nothing more.
