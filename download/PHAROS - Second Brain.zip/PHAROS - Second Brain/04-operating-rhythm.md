# Operating Rhythm

## Daily Rhythm

The daily surface is not mainly for task management.
It is for continuity restoration and synthesis steering.

Each day, the system should answer:

- What threads are alive?
- Which projects are drifting?
- What synthesis is overdue?
- What pressure keeps resurfacing?
- What one move would restore momentum?

## Session Opening

At the start of a work session:

1. restore the current state of active projects
2. review live tensions and recent moves
3. confirm which artifact or direction is currently canonical
4. note any contradiction that must remain visible
5. identify the highest-pressure synthesis target
6. define one meaningful synthesis move

## Session Closing

Before stopping:

1. update project state
2. record what changed
3. mark unresolved tensions
4. update canonical or supersession status if it changed
5. specify the next synthesis move
6. deprecate or flag anything misleading

## Weekly Rhythm

Once a week:

- review active and dormant projects
- identify recurring motifs across projects
- promote emerging threads into project candidates
- retire dead threads
- audit drift between project intent and current materials
- review which artifacts are current, superseded, or stale
- review which contradictions should remain preserved rather than reconciled
- prune maintenance surfaces that no longer reduce restart cost

## Monthly Rhythm

Once a month:

- review whether the architecture still supports work
- simplify any surface that has become maintenance theater
- identify where retrieval is masking synthesis failure
- identify where graph closure or linkage has outpaced discrimination
- review whether authority and review-status distinctions are still clear
- revise templates and agent behaviors if needed

## Core Rule

Never end a session with only more material.
End with updated state and a named next move.
