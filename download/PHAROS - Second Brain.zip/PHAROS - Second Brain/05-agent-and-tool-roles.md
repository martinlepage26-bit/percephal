# Agent and Tool Roles

## Principle

Tools and agents should be assigned by function, not prestige.

The question is not "which model is smartest?"
The question is "which role helps continuity and synthesis without producing more debris?"

## Obsidian

Use for:

- note persistence
- project records
- local links
- dashboards and hubs
- lightweight metadata

Do not expect it to perform synthesis by itself.

## Claude or Similar Conversational Models

Use for:

- synthesis prompting
- bridge proposals
- contradiction detection
- project-state reconstruction
- outline drafting
- reflective review

Risk:
high fluency can simulate understanding.
Require grounding and explicit uncertainty marking.

## Codex or Similar Execution Agents

Use for:

- file transformations
- automation
- scripted restructuring
- metadata repair
- dashboard generation
- batch operations

Risk:
building elegant infrastructure that no longer serves actual synthesis.

## Retrieval or Graph Systems

Use for:

- semantic resurfacing
- relation detection
- latent cluster discovery
- context expansion

Risk:
mistaking adjacency for significance.

## Agent Logs

Treat logs as prosthetic continuity residues.

They should preserve:

- what the agent believed the project was
- what changed
- what remained uncertain
- what the next move was

If logs become merely verbose transcripts, they are failing.

## Assignment Rule

Every tool or agent should be evaluated by one question:

Did this reduce the cost of project synthesis, or merely produce more organized material?
