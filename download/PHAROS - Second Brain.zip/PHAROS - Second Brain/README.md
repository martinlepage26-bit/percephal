# Method Brain

This package defines a method brain: a governed cognitive prosthesis for continuity-preserving project synthesis under conditions of interruption, fragmentation, overload, and uneven cognitive continuity.

It is not a note system.
It is not a memory fetish.
It is not a promise that software will think for you.

It is a method for building an external environment that helps thought survive interruption long enough to become work.

## Core Thesis

The system exists to help a person repeatedly convert fragmented thought into sustained intellectual projects when continuity and synthesis cannot be reliably maintained in working memory alone.

Its center of gravity is not capture.
It is not search.
It is not linking for its own sake.

Its center of gravity is project state:
the live question, tensions, materials, blockers, and next synthesis move that let a project resume without being rebuilt from scratch.

## What This Package Is For

Use this package if the real problem is something like:

- too many fragments, too little project continuity
- decent retrieval, weak synthesis
- repeated loss of momentum across interruptions
- AI assistance that sounds coherent but does not preserve traceable continuity
- a vault that behaves more like a library than a working synthesis environment

Do not use this package as an excuse to build a giant ontology before you can continue a single live project.

## Read This First

If you only read three files, read these:

1. `00-purpose-and-positioning.md`
2. `03-project-state-model.md`
3. `04-operating-rhythm.md`

That is the operational spine.

If you are implementing with agents, add:

4. `12-agent-operating-protocol.md`

If you are implementing in Obsidian, add:

5. `11-obsidian-implementation-templates.md`

## Package Map

- `00-purpose-and-positioning.md`
- What the method is, what problem it solves, and what counts as success.

- `01-design-principles.md`
- The design rules: continuity over collection, projects over topics, synthesis over retrieval, governance over fluency.

- `02-system-architecture.md`
- The five-layer architecture: memory, continuity, project state, synthesis, governance.

- `03-project-state-model.md`
- The core object of the system and the fields every live project should carry.

- `04-operating-rhythm.md`
- The daily, weekly, and monthly rhythms that keep continuity alive.

- `05-agent-and-tool-roles.md`
- The functional division of labor between Obsidian, conversational models, execution agents, and retrieval systems.

- `06-governance-and-integrity.md`
- The safeguards against false continuity, ungrounded fluency, and silent drift.

- `07-minimum-implementation.md`
- The smallest viable rollout path for making the method real.

- `08-recommendations-from-assessment.md`
- The strategic corrections: canonicality, contradiction preservation, thin operational surfaces, and protection against recursive coherence inflation.

- `09-failure-modes-and-recovery.md`
- The main ways the system goes bad and how to recover without trying to save the entire vault at once.

- `10-domain-translation-high-responsibility-professions.md`
- How the method translates into accounting, audit, legal, compliance, and other high-responsibility settings.

- `11-obsidian-implementation-templates.md`
- Practical templates and naming conventions for building the method inside an ordinary Obsidian vault.

- `12-agent-operating-protocol.md`
- The behavioral rules agents must follow so they support continuity instead of damaging it.

- `method-brain-summary.txt`
- Short plain-text summary for fast sharing.

## Recommended Reading Order

Read in this order once:

1. purpose
2. principles
3. architecture
4. project state
5. operating rhythm
6. governance
7. implementation
8. recommendations
9. failure and recovery
10. domain translation
11. Obsidian templates
12. agent protocol

Then stop reading and start using the project-state model.

## Minimum Working Core

The minimum working core of the method is:

- one daily dashboard
- one active projects hub
- one project-state note per live project
- one agent log or handoff note per session
- one weekly review

Everything else should justify itself against that core.

## Evaluation Standard

The method is working if it can answer, quickly and credibly:

- What projects are alive?
- What is each project trying to resolve?
- What tensions are active?
- What materials matter right now?
- What changed since the last meaningful pass?
- What is the next synthesis move?

If it cannot answer those questions, it is still mostly a library.

## Final Rule

Do not optimize this package for elegance, completeness, or graph closure.

Optimize it for this:
thought surviving interruption long enough to become work.
