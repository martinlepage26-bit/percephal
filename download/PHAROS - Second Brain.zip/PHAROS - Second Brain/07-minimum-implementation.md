# Minimum Implementation

## Start Smaller Than Your Ambition

Do not build the whole architecture at once.
Build the minimum version that supports live project synthesis.

## Phase 1: Establish Core Surfaces

Create:

- one daily continuity dashboard
- one active projects hub
- one project-state template
- one agent log template
- one weekly review note

## Phase 2: Convert Live Work

Pick two or three active projects.

For each:

- create a project-state record
- link the core materials
- identify active tensions
- record the next synthesis move

Do not migrate the whole vault.
That is how people disappear into architecture instead of work.

## Phase 3: Add Controlled Retrieval

Only after the project-state records are functioning:

- add semantic resurfacing
- add cluster detection
- add retrieval-conditioned synthesis prompts
- add graph-aware context expansion

These should feed project records, not bypass them.

## Phase 4: Add Governance Loops

Implement:

- uncertainty labels
- deprecation marks
- revision summaries
- weekly drift checks
- contradiction review

## Phase 5: Evaluate Ruthlessly

After two weeks, ask:

- Did this help projects continue across interruption?
- Did it reduce restart friction?
- Did it produce better synthesis?
- Did it create maintenance overhead?
- What can be removed?

## Non-Negotiable Rule

If a new feature does not improve project continuation, state clarity, or synthesis quality, cut it.
