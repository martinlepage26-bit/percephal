# Design Principles

## 1. Continuity Over Collection

The purpose of capture is not accumulation.
It is continuity.

Anything that increases capture volume while making resumption harder is a regression.

## 2. Projects Over Topics

Topics describe areas.
Projects organize motion.

The core unit of the system is not the note, folder, or tag.
It is the active project state.

## 3. Synthesis Over Retrieval

Retrieval is necessary but insufficient.

The system must help produce:

- claims
- tensions
- bridges
- outlines
- unresolved questions
- next moves

Otherwise it is search with flattering rhetoric.

## 4. State Over Static Knowledge

Each active project must have a current state, not just associated materials.

State includes:

- live question
- working claims
- active tensions
- relevant sources
- recent moves
- blocked points
- next synthesis step

## 5. Governance Over Fluency

Smooth language is not proof of continuity.

The system must preserve:

- traceability
- deprecation logic
- revision history
- uncertainty marking
- source grounding
- contradiction visibility

Without those, apparent coherence can become a form of epistemic damage.

## 6. Lowest Viable Complexity

The architecture must remain maintainable under reduced cognitive stamina.

Any layer that requires constant manual tending, frequent ontology debates, or obsessive triage is suspect.

The right system is not the most comprehensive one.
It is the one that remains usable when cognition is uneven.
