# System Architecture

## Overview

The method brain has five layers.

## 1. Memory Layer

Raw persistence.

This includes:

- notes
- documents
- transcripts
- PDFs
- conversations
- embeddings
- metadata
- entities
- backlinks

Typical tools:

- Obsidian
- file system storage
- embeddings stores
- graph retrieval systems

This layer remembers.
It does not synthesize.

## 2. Continuity Layer

The ability to resume work without rebuilding the whole context by hand.

This includes:

- session state
- thread persistence
- genealogy
- deprecation tracking
- drift detection
- audit traces
- resumable briefings

This layer preserves motion across interruption.

## 3. Project-State Layer

This is the central layer.

For each live project, the system stores:

- current question
- scope
- active tensions
- working claims
- current evidence base
- recent changes
- unresolved contradictions
- blocked points
- next synthesis move

Without this layer, synthesis becomes episodic and cannot accumulate.

## 4. Synthesis Layer

This layer transforms material.

Its functions include:

- clustering pressure points
- surfacing convergences
- proposing conceptual bridges
- identifying emerging project nuclei
- exposing contradiction zones
- generating provisional outlines
- turning threads into arguments or action

This layer does not replace judgment.
It scaffolds it.

## 5. Governance Layer

This layer protects integrity.

It manages:

- claim traceability
- evidence discipline
- uncertainty marking
- revision control
- anti-fluency safeguards
- deprecation control
- recursive auditability

The point is not generic safety theater.
The point is trustworthy continuity.

## Diagnostic Rule

When a system feels impressive, ask which layer it actually serves.

Many tools claim to support synthesis while only improving memory or retrieval.
