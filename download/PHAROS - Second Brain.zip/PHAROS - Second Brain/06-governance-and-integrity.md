# Governance and Integrity

## Why Governance Exists

The danger is not only forgetting.
It is false continuity.

A system can sound coherent while quietly drifting from evidence, erasing uncertainty, or flattening contradiction.

Governance exists to prevent fluency from impersonating thought.

## Required Safeguards

### Traceability

Claims should point back to materials, not float free as polished summaries.

### Authority Status

The system must distinguish descriptive relation from legitimate authority.

This means:

- retrieval does not equal validation
- recurrence does not equal importance
- linkage does not equal proof
- graph centrality does not equal canonical status

Materials can be related, relevant, or recurring without becoming authoritative.

### Uncertainty Marking

The system should distinguish:

- known
- inferred
- tentative
- contradictory
- deprecated

### Deprecation Logic

Old claims should not simply vanish.
They should be marked as superseded, revised, or abandoned, with reason where useful.

### Contradiction Visibility

Do not smooth over internal disagreement too early.
Visible contradiction is often a sign that real work remains.

### Canonicality and Supersession

The system should make it clear:

- what is current
- what is provisional
- what has been superseded
- what remains usable but noncanonical

Without this, revision memory becomes accumulation without authority.

### Revision Memory

Important shifts in a project's direction should be legible over time.

### Anti-Fluency Checks

Before accepting a synthesis, ask:

- What evidence grounds this?
- What is the status of the sources or relations being used?
- What did this leave out?
- What contradiction did this flatten?
- What is still uncertain?
- What changed from the previous state?

## Governance Rule

Prefer an honest partial synthesis over a smooth false whole.
