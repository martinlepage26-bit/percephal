# Failure Modes and Recovery

## Why This File Exists

The method brain is not threatened only by technical failure.
Its more serious dangers are structural, epistemic, and operational.

This file names the most likely failure modes and provides recovery moves that keep the system usable.

## 1. Archive Creep

### Pattern

The system becomes very good at collecting material and very bad at turning it into motion.

Signs:

- more notes than project updates
- more captured fragments than synthesized claims
- retrieval activity without project movement
- growing hubs with stagnant projects

### Recovery

- freeze new structure work for one week
- pick two active projects only
- update their project-state records
- convert loose materials into tensions, claims, or blockers
- discard or archive anything that does not change project state

## 2. Recursive Coherence Inflation

### Pattern

Everything becomes linked, interpretable, and narratable.
Distinctions weaken.
The system produces coherence faster than it produces discrimination.

Signs:

- universal cross-linking
- too many bridge notes
- everything feels relevant to everything else
- thematic adjacency is mistaken for operational importance

### Recovery

- stop link expansion passes
- require each new link to declare its type:
  dependency, evidence, contradiction, adjacency, or speculation
- review one project and remove nonconsequential links
- restore a clear distinction between what matters now and what merely resonates

## 3. Canonical Drift

### Pattern

Multiple versions of the same idea coexist without clear authority.
Nothing dies, so nothing becomes current.

Signs:

- several parallel synthesis notes
- no clear supersession chain
- recurring uncertainty about which document to trust
- old conclusions still shaping work by inertia

### Recovery

- designate one current canonical artifact per live project
- mark adjacent artifacts as candidate, supporting, deprecated, or archived
- add `supersedes`, `superseded by`, and `last reviewed` fields
- move unresolved alternatives into a contradiction or alternatives section rather than letting them float

## 4. Contradiction Erasure

### Pattern

The system gets too good at reconciliation.
Real tensions are prematurely smoothed into elegant summaries.

Signs:

- summaries that sound clean but feel weak
- missing records of disagreement
- recurring unease about a project's "resolved" state
- fragile syntheses collapsing under scrutiny

### Recovery

- add a `Contradictions To Preserve` section to the project record
- ask: what are we forcing into agreement too early?
- separate incompatible models instead of merging them
- keep unresolved contradictions visible until they are actually worked through

## 5. Maintenance Overload

### Pattern

The system requires too much tending.
Governance, dashboards, audits, and hubs multiply faster than usable output.

Signs:

- dread before opening the vault
- repeated upkeep tasks with unclear payoff
- more time spent grooming surfaces than advancing projects
- too many review rituals to complete consistently

### Recovery

- reduce to the thin core:
  daily dashboard, projects hub, project-state records, agent logs, weekly review
- pause nonessential audits for two weeks
- delete or archive duplicate surfaces
- keep only routines that change project state or reduce restart cost

## 6. Agent Transcript Bloat

### Pattern

Logs become verbose memory dumps rather than continuity tools.

Signs:

- agent logs are long but not resumable
- the next move is buried in transcript prose
- repeated re-reading without clearer state
- session handoff still feels expensive

### Recovery

- compress each log into four fields:
  project understanding, changes made, uncertainties, next move
- separate transcript storage from continuity summaries
- require a short handoff note at session close

## 7. Retrieval Without Adjudication

### Pattern

Graph or retrieval layers surface many relations, but nothing decides what matters.

Signs:

- useful-looking clusters with no downstream effect
- recurring resurfacing of the same material without project progress
- relation maps that never modify project state

### Recovery

- treat retrieval outputs as candidates only
- require every surfaced cluster to answer:
  so what changes in the project record?
- ignore any retrieval result that does not alter question, tensions, claims, blockers, or next move

## 8. Session Collapse

### Pattern

Work stops abruptly and the next return begins from confusion.

Signs:

- missing closure notes
- unclear last action
- stale project-state records
- long restart periods before meaningful work resumes

### Recovery

- never end a session without writing the next synthesis move
- update recent moves before closing
- record one sentence on what changed and one on what remains unresolved
- if collapse already happened, reconstruct only the current project state, not the whole history

## 9. Governance Theater

### Pattern

The language of rigor remains, but its operational bite disappears.

Signs:

- audits that do not change behavior
- governance memos without concrete consequences
- status labels that no one uses in decisions
- procedures maintained for symbolism

### Recovery

- ask of every governance artifact: what decision does this constrain?
- remove any governance surface that does not affect action, traceability, or legitimacy
- prefer fewer controls with real consequence over many ceremonial controls

## 10. System Self-Metabolization

### Pattern

The vault increasingly writes about itself instead of helping projects advance.

Signs:

- maps of maps
- audits of audits
- synthesis of synthesis layers
- new abstractions generated mainly to explain prior abstractions

### Recovery

- impose a moratorium on meta-architecture notes
- route all new synthesis through live project records
- allow method revision only during scheduled monthly review
- return the system to its test:
  does this help thought survive interruption long enough to become work?

## Recovery Protocol

When the system feels bloated, unclear, or false, use this order:

1. Stop adding structure.
2. Pick one or two live projects only.
3. Rebuild their current project state.
4. Preserve contradictions instead of forcing closure.
5. Re-establish one meaningful next move.
6. Archive whatever does not reduce restart cost or improve synthesis.

## Final Rule

Do not recover the whole vault.
Recover operational continuity around live projects.

That is enough.
