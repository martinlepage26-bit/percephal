# Purpose and Positioning

## What This Is

A method brain is a governed cognitive prosthesis for project synthesis.

Its job is to help transform:

- notes into threads
- threads into tensions
- tensions into synthesis
- synthesis into projects
- projects into sustained work over time

## What Problem It Solves

The central problem is not storage.
It is not search.
It is not even linking in the abstract.

The central problem is this:

Thought is interrupted.
Continuity decays.
Fragments accumulate.
Projects fail to cohere or remain coherent.

The method brain exists to reduce the cost of re-entry, preserve the state of live thinking, and support repeated project formation across breaks in continuity.

## What This Is Not

This is not a promise of an artificial second brain.
This is not a general productivity system.
This is not a static archive with decorative dashboards.

If the system only helps collect, classify, and retrieve fragments, it is incomplete.
If it cannot help recover momentum and produce new synthesis, it is failing.

## Standard of Success

The system succeeds when it can answer, quickly and credibly:

- What projects are alive?
- What is each project trying to resolve?
- What tensions are active?
- What materials matter right now?
- What changed since the last meaningful pass?
- What is the next synthesis move?

If it cannot answer those questions, it is still mostly a library.
